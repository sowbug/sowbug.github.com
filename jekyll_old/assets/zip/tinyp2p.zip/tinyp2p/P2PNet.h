/*
    tinyp2p
    Copyright � 2003 Mike Tsao

    Permission is hereby granted, free of charge, to any person obtaining a
    copy of this software and associated documentation files (the "Software"),
    to deal in the Software without restriction, including without limitation
    the rights to use, copy, modify, merge, publish, distribute, sublicense,
    and/or sell copies of the Software, and to permit persons to whom the
    Software is furnished to do so, subject to the following conditions:
    
    The above copyright notice and this permission notice shall be included in
    all copies or substantial portions of the Software.
    
    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
    OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
    MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
    NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
    DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
    OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
    USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

#include <windows.h>

class P2PNet {
public:
    typedef enum {
        Identity = 0,
        TextMessage,
        Goodbye,
    } PacketType;
protected:
    typedef enum {
        Initialized = 0,
        ReadingPacket,
        HandlingIdentityPacket,
        HandlingTextMessagePacket,
        HandlingGoodbyePacket,
    } State;
    typedef int(SendBytesFunc)(void *, char *, int);
    typedef int(HandlePacketFunc)(void *, PacketType, void*, void*);
    SendBytesFunc *sbf;
    HandlePacketFunc *hpf;
    void *ctx;
    int packet_len;
    State state;
    char *packet;
    int packet_offset;

    void reset_packet(void);

public:
    P2PNet(SendBytesFunc *sbf, HandlePacketFunc *hpf, void *ctx);
    virtual ~P2PNet();

    int HandleBytes(char *data, int data_len);
    int SendPacket(PacketType packet_type, char *data, int data_len);
};
