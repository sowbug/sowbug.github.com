/*
    tinyp2p
    Copyright � 2003 Mike Tsao

    Permission is hereby granted, free of charge, to any person obtaining a
    copy of this software and associated documentation files (the "Software"),
    to deal in the Software without restriction, including without limitation
    the rights to use, copy, modify, merge, publish, distribute, sublicense,
    and/or sell copies of the Software, and to permit persons to whom the
    Software is furnished to do so, subject to the following conditions:
    
    The above copyright notice and this permission notice shall be included in
    all copies or substantial portions of the Software.
    
    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
    OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
    MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
    NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
    DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
    OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
    USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

#include <windows.h>
#include <windowsx.h>
#include "P2PNet.h"
#include "resource.h"

#define P2P_PORT (8888)

typedef struct
{
    SOCKET socket_connect;
    SOCKET socket_listen;
    P2PNet *p2pnet;
    HWND hwnd;
    char identity[64 + 1];
} p2p_t;

static void addStatusText(HWND hwnd, char *text)
{
    HWND hwndCtl = GetDlgItem(hwnd, IDC_STATUS);
    SendMessage(hwndCtl, EM_SETSEL, (WPARAM)-1, (LPARAM)-1);
    SendMessage(hwndCtl, EM_REPLACESEL, FALSE, (LPARAM)text);
}

static void handleListen(p2p_t *p2p, HWND hwnd)
{
    int rc = 0;
    p2p->socket_listen = socket(AF_INET, SOCK_STREAM, 0);
    int optval = 1;
    setsockopt(p2p->socket_listen,
        SOL_SOCKET,
        SO_REUSEADDR,
        (const char *)&optval,
        sizeof(optval));
    struct sockaddr_in sa;
    
    sa.sin_family = AF_INET;
    sa.sin_port = htons(P2P_PORT);
    sa.sin_addr.s_addr = INADDR_ANY;
    memset(&sa.sin_zero, 0, sizeof(sa.sin_zero));

    rc = bind(p2p->socket_listen, (struct sockaddr *)&sa, sizeof(sa));
    if (0 == rc) {
        rc = listen(p2p->socket_listen, 16);
        if (0 == rc) {
            WSAAsyncSelect(p2p->socket_listen,
                hwnd,
                WM_APP,
                FD_ACCEPT);
        }
    }
    if (0 == rc) {
        addStatusText(hwnd, TEXT("Listening on port 8888.\r\n"));
    } else {
        addStatusText(hwnd, TEXT("Couldn't start listening.\r\n"));
    }
}

static void enableButtons(HWND hwnd, BOOL connected)
{
    EnableWindow(GetDlgItem(hwnd, IDC_PEER_IP), !connected);
    EnableWindow(GetDlgItem(hwnd, IDC_CONNECT), !connected);
    EnableWindow(GetDlgItem(hwnd, IDC_MESSAGE), connected);
    EnableWindow(GetDlgItem(hwnd, IDC_SEND), connected);
}

static int sendBytes(void *ctx, char *data, int data_len)
{
    p2p_t *p2p = (p2p_t *)ctx;
    return send(p2p->socket_connect, data, data_len, 0);
}

static int handlePacket(void *ctx,
                        P2PNet::PacketType packet_type,
                        void *p1,
                        void *p2)
{
    char *data = (char*)p1;
    int data_len = (int)(LONG_PTR)p2;
    p2p_t *p2p = (p2p_t *)ctx;
    char msg[254 + 1];
    switch (packet_type) {
        case P2PNet::Identity:
            wsprintf(msg, "Peer's identity is '%s.'\r\n", data);
            addStatusText(p2p->hwnd, msg);
            break;
        case P2PNet::TextMessage:
            wsprintf(msg, "R: %s\r\n", data);
            addStatusText(p2p->hwnd, msg);
            Beep(880, 20);
            break;
        case P2PNet::Goodbye:
            addStatusText(p2p->hwnd, "Peer is disconnecting. Goodbye!\r\n");
            break;
    }
    return 0;
}

static BOOL onInitDialog(HWND hwnd, HWND hwndFocus, LPARAM lParam)
{
    p2p_t *p2p = (p2p_t *)lParam;

    SetWindowLongPtr(hwnd, GWLP_USERDATA, (LONG)lParam);

    ZeroMemory(p2p, sizeof(p2p_t));
    p2p->socket_connect = INVALID_SOCKET;
    p2p->socket_listen = INVALID_SOCKET;
    p2p->p2pnet = new P2PNet(sendBytes, handlePacket, p2p);
    p2p->hwnd = hwnd;
    wsprintf(p2p->identity, "Peer %08x", GetTickCount());

    addStatusText(hwnd, (LPSTR)"Started.\r\n");
    handleListen(p2p, hwnd);
    enableButtons(hwnd, FALSE);
    return TRUE;
}

static void handleIdentitySend(p2p_t *p2p, HWND hwnd, char *s)
{
    char msg[254 + 1];
    p2p->p2pnet->SendPacket(P2PNet::Identity, s, (int)strlen(s));
    wsprintf(msg, "Sent identity '%s.'\r\n", s);
    addStatusText(hwnd, msg);
}

static void handleMessageSend(p2p_t *p2p, HWND hwnd, char *s)
{
    char msg[254 + 1];
    p2p->p2pnet->SendPacket(P2PNet::TextMessage, s, (int)strlen(s));
    wsprintf(msg, "S: %s\r\n", s);
    addStatusText(hwnd, msg);
}

static void handleConnect(p2p_t *p2p, HWND hwnd, char *s)
{
    struct sockaddr_in sa;
    char msg[512 + 1];
    
    p2p->socket_connect = socket(AF_INET, SOCK_STREAM, 0);
    int optval = 1;
    setsockopt(p2p->socket_connect,
        SOL_SOCKET,
        SO_REUSEADDR,
        (const char *)&optval,
        sizeof(optval));

    WSAAsyncSelect(p2p->socket_connect,
        hwnd,
        WM_APP,
        FD_CONNECT);

    sa.sin_family = AF_INET;
    sa.sin_port = htons(P2P_PORT);
    sa.sin_addr.s_addr = inet_addr(s);
    memset(&sa.sin_zero, 0, sizeof(sa.sin_zero));

    wsprintf(msg, "Connecting to %s...\r\n", s);
    addStatusText(hwnd, msg);
    int rc = connect(p2p->socket_connect, (struct sockaddr *)&sa, sizeof(sa));
    enableButtons(hwnd, TRUE);
}

static void handleConnected(p2p_t *p2p, HWND hwnd, SOCKET s, int err)
{
    if (ERROR_SUCCESS == err) {
        addStatusText(hwnd, "Connected.\r\n");
        handleIdentitySend(p2p, hwnd, p2p->identity);
        enableButtons(hwnd, TRUE);
        WSAAsyncSelect(p2p->socket_connect,
            hwnd,
            WM_APP,
            FD_READ | FD_CLOSE);
        enableButtons(hwnd, TRUE); // Once again just to be sure.
    } else {
        addStatusText(hwnd, "Couldn't connect.\r\n");
        enableButtons(hwnd, FALSE);
    }
}

static void handleAccept(p2p_t *p2p, HWND hwnd)
{
    struct sockaddr_in sa;
    
    sa.sin_family = AF_INET;
    sa.sin_port = htons(P2P_PORT);
    sa.sin_addr.s_addr = INADDR_ANY;
    memset(&sa.sin_zero, 0, sizeof(sa.sin_zero));
    int sa_size = sizeof(sa);
    p2p->socket_connect =
        accept(p2p->socket_listen, (struct sockaddr *)&sa, &sa_size);
    WSAAsyncSelect(p2p->socket_connect,
        hwnd,
        WM_APP,
        FD_READ | FD_CLOSE);
    char status[512 + 1];
    wsprintf(status,
        "Accepted connection from %s.\r\n",
        inet_ntoa(sa.sin_addr));
    addStatusText(hwnd, status);
    handleIdentitySend(p2p, hwnd, p2p->identity);
    enableButtons(hwnd, TRUE);
    Beep(440, 150);
    Beep(880, 100);
}

static void handleClose(p2p_t *p2p, HWND hwnd, SOCKET s)
{
    if (p2p->socket_connect == s) {
        addStatusText(hwnd, "Peer closed connection.\r\n");
        closesocket(p2p->socket_connect);
        p2p->socket_connect = INVALID_SOCKET;
        Beep(880, 150);
        Beep(440, 100);
    }
    enableButtons(hwnd, FALSE);
}

static void handleRead(p2p_t *p2p, HWND hwnd, SOCKET s)
{
    char readbuf[4096 + 1];
    int rc = recv(s, readbuf, 4096, 0);
    if (rc > 0) {
        p2p->p2pnet->HandleBytes(readbuf, rc);
    }
}

static void onCommand(HWND hwnd, int id, HWND hwndCtl, UINT codeNotify)
{
    p2p_t *p2p = (p2p_t *)(LONG_PTR)GetWindowLongPtr(hwnd, GWLP_USERDATA);
    switch (id) {
        case IDOK:
            if (INVALID_SOCKET != p2p->socket_listen) {
                closesocket(p2p->socket_listen);
            }
            if (INVALID_SOCKET != p2p->socket_connect) {
                p2p->p2pnet->SendPacket(P2PNet::Goodbye, NULL, 0);
                closesocket(p2p->socket_connect);
            }
            EndDialog(hwnd, id);
            break;
        case IDC_CONNECT:
            {
                char str[512 + 1];
                GetDlgItemText(hwnd, IDC_PEER_IP, str, 512);
                handleConnect(p2p, hwnd, str);
            }
            break;
        case IDC_SEND:
            {
                char str[512 + 1];
                GetDlgItemText(hwnd, IDC_MESSAGE, str, 512);
                handleMessageSend(p2p, hwnd, str);
            }
            break;
    }
}

static INT_PTR CALLBACK dlg_proc(HWND hwnd,
                                 UINT uMsg,
                                 WPARAM wParam,
                                 LPARAM lParam)
{
    p2p_t *p2p = (p2p_t *)(LONG_PTR)GetWindowLongPtr(hwnd, GWLP_USERDATA);
    switch (uMsg) {
        HANDLE_MSG(hwnd, WM_INITDIALOG, onInitDialog);
        HANDLE_MSG(hwnd, WM_COMMAND, onCommand);
        case WM_APP:
            switch (WSAGETSELECTEVENT(lParam)) {
                case FD_READ:
                    handleRead(p2p, hwnd, (SOCKET)wParam);
                    break;
                case FD_CONNECT:
                    handleConnected(p2p,
                        hwnd,
                        (SOCKET)wParam,
                        WSAGETSELECTERROR(lParam));
                    break;
                case FD_ACCEPT:
                    handleAccept(p2p, hwnd);
                    break;
                case FD_CLOSE:
                    handleClose(p2p, hwnd, (SOCKET)wParam);
                    break;
            }
            return TRUE;
    }
    return FALSE;
}

int DoDialog(HINSTANCE hInstance, HWND hwndMain)
{
    p2p_t p2p;
    INT_PTR result = DialogBoxParam(hInstance,
        MAKEINTRESOURCE(IDD_MAIN),
        hwndMain,
        dlg_proc,
        (LONG_PTR)&p2p);
    return (int)result;
}
