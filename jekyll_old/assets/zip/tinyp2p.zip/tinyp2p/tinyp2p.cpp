/*
    tinyp2p
    Copyright � 2003 Mike Tsao

    Permission is hereby granted, free of charge, to any person obtaining a
    copy of this software and associated documentation files (the "Software"),
    to deal in the Software without restriction, including without limitation
    the rights to use, copy, modify, merge, publish, distribute, sublicense,
    and/or sell copies of the Software, and to permit persons to whom the
    Software is furnished to do so, subject to the following conditions:
    
    The above copyright notice and this permission notice shall be included in
    all copies or substantial portions of the Software.
    
    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
    OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
    MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
    NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
    DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
    OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
    USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

#include <windows.h>
#include <commctrl.h>
#include "resource.h"
#include "MainDialog.h"

static ATOM registerWindowClass(HINSTANCE hInstance)
{
    WNDCLASSEX wc;

    ZeroMemory(&wc, sizeof(WNDCLASSEX));

    wc.cbSize = sizeof(WNDCLASSEX);
    wc.lpfnWndProc = DefWindowProc;
    wc.hInstance = hInstance;
    wc.hIcon = (HICON)LoadImage(hInstance,
        MAKEINTRESOURCE(IDI_APP),
        IMAGE_ICON,
        0,
        0,
        LR_DEFAULTCOLOR);
    wc.lpszClassName = "tinyp2p {A766AFC4-CD45-4281-909C-4E875793DE7C}";

    return RegisterClassEx(&wc);
}

static void unregisterWindowClass(HINSTANCE hInstance, ATOM atom)
{
    UnregisterClass(MAKEINTATOM(atom), hInstance);
}

static HWND createMainWindow(HINSTANCE hInstance, ATOM windowClass)
{
    return CreateWindowEx(WS_EX_TOOLWINDOW,
        MAKEINTATOM(windowClass),
        NULL,
        WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        NULL,
        NULL,
        hInstance,
        NULL);
}

static void destroyMainWindow(HWND hwnd)
{
    DestroyWindow(hwnd);
}

static void initSocketLibrary(void)
{
    WSADATA wsaData;
    WSAStartup(MAKEWORD(1, 1), &wsaData);
}

static void terminateSocketLibrary(void)
{
    WSACleanup();
}

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     char *lpCmdLine,
                     int nCmdShow)
{
    int result = ERROR_SUCCESS;
    initSocketLibrary();
    InitCommonControls();
    ATOM windowClass = registerWindowClass(hInstance);
    if (0 != windowClass) {
        HWND hwndMain = createMainWindow(hInstance, windowClass);
        if (NULL != hwndMain) {
            DoDialog(hInstance, hwndMain);
            destroyMainWindow(hwndMain);
        }
        unregisterWindowClass(hInstance, windowClass);
    }
    terminateSocketLibrary();
    return 0;
}
