/*
    tinyp2p
    Copyright � 2003 Mike Tsao

    Permission is hereby granted, free of charge, to any person obtaining a
    copy of this software and associated documentation files (the "Software"),
    to deal in the Software without restriction, including without limitation
    the rights to use, copy, modify, merge, publish, distribute, sublicense,
    and/or sell copies of the Software, and to permit persons to whom the
    Software is furnished to do so, subject to the following conditions:
    
    The above copyright notice and this permission notice shall be included in
    all copies or substantial portions of the Software.
    
    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
    OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
    MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
    NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
    DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
    OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
    USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

#include "P2PNet.h"

P2PNet::P2PNet(SendBytesFunc *sbf, HandlePacketFunc *hpf, void *ctx)
{
    this->sbf = sbf;
    this->hpf = hpf;
    this->ctx = ctx;
    this->state = Initialized;
    this->packet_len = 0;
    this->packet = NULL;
    this->packet_offset = 0;
}

P2PNet::~P2PNet()
{
    reset_packet();
}

void P2PNet::reset_packet(void)
{
    if (NULL != packet) {
        free(packet);
        packet = NULL;
    }
    packet_offset = 0;
    packet_len = 0;
}

#define ADVANCE(p, n, c) {p+=(c); n-=(c);}
int P2PNet::HandleBytes(char *data, int data_len)
{
    State nextState = Initialized;
    BOOL keep_looping = FALSE;

    while (data_len > 0 || keep_looping) {
        keep_looping = FALSE;

        switch (state) {
            case Initialized:
                {
                    PacketType packet_type = (PacketType)*data;
                    ADVANCE(data, data_len, 1);
                    char len = *data;
                    ADVANCE(data, data_len, 1);
                    packet_len = (unsigned char)len;
                    if (packet_len > 0) {
                        packet = (char*)malloc(packet_len);
                    } else {
                        packet = NULL;
                    }
                    packet_offset = 0;
                    state = ReadingPacket;
                    switch (packet_type) {
                        case Identity:
                            nextState = HandlingIdentityPacket;
                            break;
                        case TextMessage:
                            nextState = HandlingTextMessagePacket;
                            break;
                        case Goodbye:
                            nextState = HandlingGoodbyePacket;
                            break;
                        default:
                            return -1;
                    }
                    keep_looping = TRUE;
                }
                break;
            case ReadingPacket:
                if (packet_len > packet_offset) {
                    if (packet_len - packet_offset < data_len) {
                        memcpy(packet + packet_offset,
                            data,
                            packet_len - packet_offset);
                        packet_offset = packet_len;
                        ADVANCE(data, data_len, packet_len - packet_offset);
                    } else {
                        memcpy(packet + packet_offset, data, data_len);
                        packet_offset += data_len;
                        ADVANCE(data, data_len, data_len);
                    }
                }
                if (packet_len == packet_offset) {
                    state = nextState;
                    keep_looping = TRUE;
                }
                break;
            case HandlingIdentityPacket:
                state = Initialized;
                hpf(ctx, Identity, packet, (void*)(LONG_PTR)packet_len);
                reset_packet();
                break;
            case HandlingTextMessagePacket:
                state = Initialized;
                hpf(ctx, TextMessage, packet, (void*)(LONG_PTR)packet_len);
                reset_packet();
                break;
            case HandlingGoodbyePacket:
                state = Initialized;
                hpf(ctx, Goodbye, NULL, NULL);
                reset_packet();
                break;
            default:
                return -1;
        }
    }
    return 0;
}

int P2PNet::SendPacket(PacketType packet_type, char *data, int data_len)
{
    switch (packet_type) {
        case Identity:
            {
                char packet[254 + 1];
                packet[0] = (char)Identity;
                packet[1] = data_len + 1;
                memcpy(&packet[2], data, data_len);
                packet[2 + data_len] = '\0';
                return sbf(ctx, packet, packet[1] + 2);
            }
        case TextMessage:
            {
                char packet[254 + 1];
                packet[0] = (char)TextMessage;
                packet[1] = data_len + 1;
                memcpy(&packet[2], data, data_len);
                packet[2 + data_len] = '\0';
                return sbf(ctx, packet, packet[1] + 2);
            }
        case Goodbye:
            {
                char packet[254 + 1];
                packet[0] = (char)Goodbye;
                packet[1] = 0;
                return sbf(ctx, packet, 2);
            }
        default:
            break;
    }
    return 0;
}
